# Supabase backend — next implementation step

The current website is a frontend preview. Before real accounts or player data are enabled, create a Supabase project and implement the backend with Row Level Security.

Required tables:
- profiles: auth user ID, unique HYSI ID, username, Free Fire UID, role, status
- tournaments: title, mode, slots, start time, status, rules
- registrations: tournament ID, player ID, registration status
- private_room_credentials: tournament ID, room ID, password, publish time (must never be public-readable)
- coin_ledger: player ID, amount, reason, reference, timestamp
- daily_checkins: player ID and date with a unique(player_id, date) constraint
- reports and admin_audit_logs

Security rules:
1. Never allow public sign-up to choose owner/moderator role.
2. Assign moderator permissions only from an authenticated owner action.
3. Do not expose room passwords in public tournament queries.
4. Award daily 10 coins through an atomic server-side function, once per day.
5. Validate tournament capacity and duplicate registration on the server.
6. Blocked/suspended users must be prevented from joining.
7. Keep service-role secrets server-side only.
8. Treat coins as non-cash points; no purchase, transfer, withdrawal or paid entry in this starter.

Suggested next step: connect Supabase Auth (Google + email), then implement protected server actions and test policies before launch.
